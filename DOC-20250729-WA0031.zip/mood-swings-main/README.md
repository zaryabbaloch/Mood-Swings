# MoodSwings

An interactive Flutter animation showcasing fluid emotion transitions with custom eye and mouth animations.

## Features

- Smooth gradient transitions between emotions
- Blinking eye animations with realistic timing
- Dynamic facial expressions
- Interactive slider control

Built with Flutter and love ❤️

[Get the code →](https://github.com/Mani821/mood-swings)