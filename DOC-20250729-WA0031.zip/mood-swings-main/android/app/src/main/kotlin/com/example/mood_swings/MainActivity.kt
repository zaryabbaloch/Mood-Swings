package com.example.mood_swings

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
